A simple jQuery pagination plugin and 3 CSS themes.

[Read Full Documentation](http://flaviusmatis.github.com/simplePagination.js/)